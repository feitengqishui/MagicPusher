# 大魔术师推币模拟器 Android 工程（0.2.0）

这是一个可离线运行的 Android WebView 工程：游戏页面和脚本全部打包在 APK 内，不需要联网权限。
本版增加了金币堆叠/碰撞近似、推板往复、自动投币、余额循环回收、活动入口和安卓云构建工作流。

## 如何在手机上生成 APK（无需电脑）
1. 在 GitHub 手机网页登录账号，创建一个空仓库，例如 `MagicPusher`。
2. 将本 ZIP 解压后，把其中所有文件和隐藏目录 `.github` 上传到仓库根目录（确保路径层级不多套一层文件夹）。
3. 打开仓库的 Actions 页面，选择 `Build Android APK`，点 `Run workflow`；首次可能需要启用 Actions。
4. 构建成功后进入该次运行页面，在 Artifacts 下载 `MagicPusher-debug-apk`，解压得到 `app-debug.apk`。
5. Android 安装时按系统提示允许该文件来源安装。

## 工程结构
- `app/src/main/assets/index.html`：离线游戏界面与玩法逻辑
- `app/src/main/java/.../MainActivity.java`：全屏竖屏 WebView 容器
- `.github/workflows/android.yml`：GitHub Actions 云端 APK 构建
- Gradle / Android Gradle Plugin 版本在 settings.gradle、app/build.gradle 中定义

## 当前版本边界
这是可运行的早期模拟器工程，不是对原机台的完整复刻。当前碰撞是轻量自编物理近似，活动入口已接入基础计数/奖励逻辑，但尚未实现原机台全部机构、真实刚体求解、完整关卡与 JP 奖池。APK 需要由 GitHub Actions 实际构建后才会产生；本次交付的是构建工程，不冒称 APK 已生成。
